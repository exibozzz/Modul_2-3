<?php

$folder = [

    "linkovi" => [

        "glavna" => "home.php",
        "o_nama" => "about_us.php",
        "kontakt" => "contact.php"
    ],

    "imena"  => [

        "glavna" => "Glavna",
        "o_nama" => "O nama",
        "kontakt" => "Kontakt"
    ]

    
    ];

    $trenutna_godina = date("Y");
    $naslov = "Assoc Array";



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$naslov?></title>
</head>
<body>


<nav>
<a href="<?=$folder["linkovi"]["glavna"]?>"><?=$folder["imena"]["glavna"]?></a>
<a href="<?=$folder["linkovi"]["o_nama"]?>"><?=$folder["imena"]["o_nama"]?></a>
<a href="<?=$folder["linkovi"]["kontakt"]?>"><?=$folder["imena"]["kontakt"]?></a>    
</nav>

<footer>
    <p>Copyright &copy mojsajt <?=$trenutna_godina?></p>
</footer>
    
</body>
</html>